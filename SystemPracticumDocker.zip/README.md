As a part of our System Practicum Mini-Project, our team, is setting up a server to host various apps created by students of IIT Mandi on different platforms like
- LAMP
- Ruby on Rails, Django
- Node.js

The idea is to keep all these platforms in seperate containers and allow sudo access within these containers to the students.

#######################################################################
We have used the base ubuntu image and added open-ssh server, supervisor and vim to it.
Base ubuntu dockerfile is the following :

FROM ubuntu:latest
RUN apt-get update
RUN apt-get install openssh-server
RUN apt-get install vim
RUN apt-get install supervisor


#######################################################################
As for the Jmeter, we need to configure the values of number of threads and path for the three different configuration.
There is only one file in TestScripts folder. We just need to change the parameters in the file using Jmeter GUI or manually for the different cases.
